import pandas as pd
import numpy as np


def extractDataFrame(fileName):
    '''Function to extract the dataframe from the text file into a pandas DataFrame.'''

    Z = pd.read_csv(fileName, sep='\t\t', engine="python")

    Z = Z.reset_index()

    data = Z.iloc[1:,1:].values
    index = Z.level_0.iloc[1:].values
    columns = ['n_actual', 'n_average', 'n_variance', 'ZScore']

    return pd.DataFrame(data, index, columns, dtype=float)

def extractIDs(df):
    '''Function to extract the IDs that match a certain condition.'''

    # print((df.ZScore >= 1).head())
    # print((df.n_actual >=1).head())
    ## Set condition, can be modified.
    cond = (df.ZScore >= 0.5) & (df.n_actual >= 0.5)

    print("Keeping {} IDs".format(cond.sum()))

    df_filtered = df[cond]

    list = df_filtered.index.tolist()

    ids = []

    for l in list:
        if "**" in l:
            l = l[2:]
        ids.append(int(l))

    return ids

def analyzeZScore(motifSize,filePath):
    '''Main function of this module. Look at the ZScore text file and only returns certain IDs.'''

    ## write fileName
    fileName = '{}/ZScore_{}.txt'.format(filePath, motifSize)

    ## Extract Dataframe
    Z = extractDataFrame(fileName)

    ## Keep only relevant IDs (This function is subject to modification.)
    IDs = extractIDs(Z)

    print(len(IDs))

    return IDs
