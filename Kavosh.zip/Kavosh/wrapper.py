import os
from printGraph import printGraph
from analyzeZScore import analyzeZScore

def execute(inputFileName, motifSize, resultFilePath, nRandomGraphs):
    '''Executes the Kavosh algorithm and prints results on the desired text file.'''

    cmd = './Kavosh '
    cmd += '-s ' + str(motifSize) + ' '
    cmd += '-i ' + inputFileName + ' '
    if resultFilePath:
        cmd += '-o ' + resultFilePath + ' '
    if nRandomGraphs != 0:
        cmd += '-r ' + str(nRandomGraphs) + ' '

    # Call the exec for Kavosh algorithm.
    os.system(cmd)

def validateInputs(fileName, motifSize, resultFilePath, nRandomGraphs):
    '''Input validation function.'''

    if not fileName:
        raise IOError('If you don\'t give me a file, I can\'t do anything.')
    try:
        #print('trying to open file {}'.format(fileName))
        f = open(fileName, mode='rb')
    except:
        raise IOError('I need an existing file, this one doesn\'t exist.')

    if motifSize<3:
        raise ValueError('I\'m not sure looking for motifs of size 2 or lower is very intersting.')
    if motifSize>20:
        raise ValueError('Motifs of size {}! Surely you\'re not serious...'.format(motifSize))
    if not (motifSize==int(motifSize)):
        raise TypeError('Sorry, I don\'t know what a fraction of a node represents. Please use an integer for motif size.')

    if resultFilePath:
        try:
            os.system('touch ' + resultFilePath + '/test.txt')
            os.system('rm ' + resultFilePath + '/test.txt')
        except:
            raise IOError('Path \'{}\' does not exist.')
    else:
        try:
            os.system('touch result/test.txt')
            os.system('rm result/test.txt')
        except:
            print('creating result directory in current working directory.')
            os.system('mkdir result')

    if nRandomGraphs<0:
        print('Let\'s assume you don\'t want to look at any randomly generated graph.')
        nRandomGraphs = 0
    if nRandomGraphs>30:
        raise ValueError('{} random graphs! Let\'s keep it down to 30, that\'s already long enough.'.format(nRandomGraphs))
    if not (nRandomGraphs==int(nRandomGraphs)):
        print('Sorry, I need to look at entire random graphs, not fraction of them, I\'ll just use the integer part.')
        nRandomGraphs = int(nRandomGraphs)

    return fileName, motifSize, resultFilePath, nRandomGraphs


def postProcessSubgraphs():
    '''Function to read output.txt and preview graphs.'''



def main(fileName=None, motifSize=5, resultFilePath=None, nRandomGraphs=0):
    """Main function of the wrapper.
    ARGS:
        - fileName : Name of file which contains the edge list. The file should contain a first line with the total number
            of nodes and all other lines contain one edge formatted as 'ID_from ID_to'.
        - motifSize : Size of subgraph for motif discovery.
        - resultFilePath : Path to save result file.
        - nRandomGraphs : Number of random graphs to generate to compute ZScore.
    """

    # Input validation tests.
    fileName, motifSize, resultFilePath, nRandomGraphs = validateInputs(fileName, motifSize, resultFilePath, nRandomGraphs)

    # Run the Kavosh exec file.
    execute(fileName, motifSize, resultFilePath, nRandomGraphs)



if __name__=="__main__":

    graph = 'networks/Fib-25'
    n = 6
    FILTER = True

    print('Performing subgraph analysis on graph {} for motifs of size {}'.format(graph.split('/')[-1], n))
    main(fileName=graph, motifSize=n, resultFilePath='result/Fib25', nRandomGraphs=15)
    print('Finished analysis')
    if FILTER:
        print("Analyzing ZScores.")
        IDs = analyzeZScore(n,filePath='result/Fib25')
    else:
        IDs = []
    print("Rendering motifs.")
    printGraph(filePath='result/Fib25', n_nodes=n, ID=IDs)
    print("Motifs rendered in {}".format('result/Fib25'))
