Kavosh
======

Kavosh: a new algorithm for finding network motifs

Z. R. M. Kashani, H. Ahrabian, E. Elahi, A. Nowzari-Dalini, E. S. Ansari, S. Asadi, S. Mohammadi, F. Schreiber, and A. Masoudi-Nejad. (2009). Kavosh: a new algorithm for finding network motifs. BMC bioinformatics, 10(318). doi:10.1186/1471-2105-10-318
