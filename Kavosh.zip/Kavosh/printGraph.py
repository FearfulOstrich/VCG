import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

def printOnFile(g, _ax):
    '''Function to print on axis a graph.'''
    nx.draw(g, ax=_ax)

def addEdges(adjMat):
    '''Function to create a graph from an adjacency matrix'''

    g = nx.DiGraph()
    src, trg = np.where(adjMat==1)
    edges = zip(src.tolist(), trg.tolist())
    g.add_edges_from(edges)

    return g

def convertAdjMatrix(id, motifSize):
    '''Function to convert the ID to an adjacency matrix.'''

    binaryID = list(bin(id)[2:])
    adjMat = np.zeros(motifSize**2)
    k = motifSize**2-1
    while binaryID:
        adjMat[k] = binaryID[-1]
        binaryID.pop()
        k-=1

    return np.reshape(adjMat, (motifSize, motifSize))

def writeFile(ID, filePath, motifSize, fileName='Motifs'):
    '''Function to write the document which contains the graphs along with their IDs.'''

    nMotif = len(ID)
    print("Rendering {} Motifs".format(nMotif))

    fig = plt.figure(figsize=(100,100))
    for i, id in enumerate(ID):
        adjMat = convertAdjMatrix(id, motifSize)
        g = addEdges(adjMat)
        _ax = fig.add_subplot(int(np.sqrt(nMotif))+1,int(np.sqrt(nMotif))+1,i+1, frameon=True)
        nx.draw_networkx(g, ax=_ax, arrowsize=3)
        _ax.set_title("ID : {}".format(id))

    plt.savefig('{}/{}_size{}.png'.format(filePath,fileName,str(motifSize)))

def getIDs(file):
    '''Function to sparse the adjMatrix.txt file for different IDs found.'''

    id = []
    for line in file:
        if "ID: " in line:
            id.append(int(line.split(sep=': ')[-1]))

    return id

def printGraph(filePath, n_nodes, ID=[]):
    '''Function to show subgraphs based on their generated IDs.
    ARGS:
        - filePath : path towards the file adjMatrix.txt.
        - ID : list of IDs to print. default 0 prints all IDs
        '''

    f = open(filePath+'/adjMatrix_{}.txt'.format(n_nodes))

    if not isinstance(ID, list):
        raise TypeError("IDs need to be given in a list, got {}.".format(type(ID)))

    ## Compute possible IDs from text file.
    possibleID = getIDs(f)

    if ID:
        for id in frozenset(ID):
            if id not in possibleID:
                ID.remove(id)
                print("Not able to find ID {} in possible IDs so we removed it.")

    if not ID:
        print("Using all IDs found in adjMatrix.txt")
        ID = possibleID

    writeFile(ID, filePath, n_nodes)
